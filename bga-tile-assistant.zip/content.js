"use strict";(()=>{var x=[{id:"A",count:2},{id:"B",count:4},{id:"C",count:1},{id:"D",count:4},{id:"E",count:5},{id:"F",count:2},{id:"G",count:1},{id:"H",count:3},{id:"I",count:2},{id:"J",count:3},{id:"K",count:3},{id:"L",count:3},{id:"U",count:8},{id:"V",count:9},{id:"W",count:4},{id:"X",count:1},{id:"Q",count:1},{id:"R",count:3},{id:"S",count:2},{id:"T",count:1},{id:"M",count:2},{id:"N",count:3},{id:"O",count:2},{id:"P",count:3}],U=Object.fromEntries(x.map(s=>[s.id,s]));var w={1:"T",2:"S",3:"N",4:"M",5:"P",6:"O",7:"G",8:"F",9:"I",10:"H",11:"E",12:"K",13:"J",14:"L",15:"D",16:"U",17:"V",18:"W",19:"X",20:"B",21:"A",22:"C",23:"R",24:"Q"};function $(s,t,n){if(t<=0||s<=0)return 0;if(t>n)return 1;let o=1;for(let r=0;r<t;r++)o*=(n-r)/(s-r);return Math.max(0,Math.min(1,1-o))}var E=class{constructor(){this.deckCounts=new Map;this.handCounts=new Map;this.totals=new Map;this.bgaDeckSize=0;this._players=[];for(let t of x)this.deckCounts.set(t.id,t.count),this.handCounts.set(t.id,0),this.totals.set(t.id,t.count)}place(t){let n=w[t];if(!n)return;let o=this.deckCounts.get(n)??0;o>0&&this.deckCounts.set(n,o-1),this.bgaDeckSize>0&&(this.bgaDeckSize=Math.max(0,this.bgaDeckSize-1))}setState(t,n,o=0,r=[]){this.bgaDeckSize=o,this._players=r;for(let i of x)this.deckCounts.set(i.id,i.count),this.handCounts.set(i.id,0);for(let i of t){let c=w[i];if(!c)continue;let a=this.deckCounts.get(c)??0;this.deckCounts.set(c,Math.max(0,a-1))}for(let i of n){let c=w[i];if(!c)continue;let a=this.deckCounts.get(c)??0;this.deckCounts.set(c,Math.max(0,a-1)),this.handCounts.set(c,(this.handCounts.get(c)??0)+1)}}get totalInDeck(){if(this.bgaDeckSize>0)return this.bgaDeckSize;let t=0;for(let n of this.deckCounts.values())t+=n;return t}get totalLeft(){let t=0;for(let[n,o]of this.deckCounts)t+=o+(this.handCounts.get(n)??0);return t}stats(){let t=this.totalInDeck,n=[...this.handCounts.values()].some(i=>i>0),o=n?Math.ceil(t/2):Math.floor(t/2);return{tiles:x.map(i=>{let c=this.deckCounts.get(i.id)??0,a=this.handCounts.get(i.id)??0,e=t>0?Math.round($(t,c,o)*100):0,l=e>0&&t>0?Math.round(c/t*100):0;return{id:i.id,inDeck:c,inHand:a,total:this.totals.get(i.id)??i.count,nextPct:l,restPct:e}}),opponentDrawsNext:n,players:this._players}}combinedProb(t,n){let o=this.totalInDeck;if(o===0)return 0;let i=[...this.handCounts.values()].some(d=>d>0)?Math.ceil(o/2):Math.floor(o/2),c=this.deckCounts.get(t)??0,a=this.deckCounts.get(n)??0,e=t===n?c:c+a,l=d=>{if(d<=0)return 1;if(d>i)return 0;let g=1;for(let m=0;m<d;m++)g*=(i-m)/(o-m);return g},u=1-l(c)-l(a)+l(e);return Math.round(Math.max(0,Math.min(1,u))*100)}reset(){this.bgaDeckSize=0;for(let t of x)this.deckCounts.set(t.id,t.count),this.handCounts.set(t.id,0)}};var N=`/* Carcassonne Tile Tracker \u2014 all classes prefixed ctt- to avoid BGA conflicts */

.ctt-root {
  position: fixed;
  bottom: 16px;
  left: 16px;
  z-index: 2147483647;
  font-family: system-ui, -apple-system, sans-serif;
  font-size: 13px;
  line-height: 1.3;
  color: #1a1a2e;
  user-select: none;
  pointer-events: none; /* children opt back in */
}

/* \u2500\u2500 Toggle button \u2500\u2500 */
.ctt-toggle {
  pointer-events: auto;
  width: 40px;
  height: 40px;
  border-radius: 8px;
  background: #4a3728;
  color: #f5e6d0;
  border: 2px solid #c8a97e;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 20px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.45);
  transition: background 0.15s, transform 0.1s;
  padding: 0;
}

.ctt-toggle:hover {
  background: #6b4f3a;
  transform: scale(1.05);
}

/* \u2500\u2500 Panel card \u2500\u2500 */
.ctt-panel {
  pointer-events: auto;
  position: fixed;
  bottom: 64px;
  left: 16px;
  width: 512px;
  max-width: min(512px, calc(100vw - 32px));
  background: #faf6ef;
  border-radius: 10px;
  box-shadow: 0 6px 28px rgba(0, 0, 0, 0.35);
  border: 1px solid #c8a97e;
  overflow: hidden;
}

.ctt-header {
  background: #4a3728;
  color: #f5e6d0;
  padding: 8px 12px;
  font-weight: 700;
  font-size: 13px;
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.ctt-header-top {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

/* \u2500\u2500 Player scores \u2500\u2500 */
.ctt-scores {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 4px 0 2px;
  border-bottom: 1px solid rgba(255,255,255,0.12);
  margin-bottom: 2px;
  flex-wrap: wrap;
}

.ctt-score-player {
  display: flex;
  align-items: center;
  gap: 4px;
  font-size: 12px;
  font-weight: 400;
  opacity: 0.85;
}

.ctt-score-player.ctt-score--active {
  opacity: 1;
  font-weight: 700;
}

.ctt-score-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  flex-shrink: 0;
  border: 1px solid rgba(255,255,255,0.4);
}

.ctt-score-name {
  max-width: 120px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.ctt-score-val {
  font-weight: 700;
  margin-left: 2px;
  color: #f5c842;
}

.ctt-score-partial {
  font-weight: 400;
  font-size: 10px;
  color: #e0c060;
  margin-left: 2px;
  opacity: 0.85;
}

.ctt-score-sep {
  font-size: 10px;
  opacity: 0.5;
  font-style: italic;
}

.ctt-legend {
  display: flex;
  gap: 10px;
  font-size: 10px;
  font-weight: 400;
  opacity: 0.85;
}

.ctt-legend-item {
  display: flex;
  align-items: center;
  gap: 3px;
}

.ctt-legend-dot {
  width: 6px;
  height: 6px;
  border-radius: 50%;
}

.ctt-legend-dot--next { background: #2a9d8f; }
.ctt-legend-dot--rest { background: #e07b39; }

.ctt-header-title {
  white-space: nowrap;
}

.ctt-total {
  font-size: 12px;
  font-weight: 400;
  opacity: 0.85;
  white-space: nowrap;
}

/* \u2500\u2500 Tile grid \u2500\u2500 */
.ctt-grid {
  display: grid;
  grid-template-columns: repeat(8, 1fr);
  gap: 0;
  padding: 8px;
}

/* \u2500\u2500 Individual tile cell \u2500\u2500 */
.ctt-cell {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 2px;
  padding: 4px 0 3px;
  border-radius: 6px;
  transition: background 0.1s;
}

.ctt-cell:hover {
  background: #ecdfc8;
}

.ctt-cell--depleted {
  opacity: 0.3;
  filter: grayscale(1);
}

.ctt-img {
  width: 56px;
  height: 56px;
  image-rendering: pixelated;
  border-radius: 3px;
  display: block;
}

.ctt-label {
  font-size: 10px;
  font-weight: 700;
  color: #4a3728;
  white-space: nowrap;
  letter-spacing: 0.02em;
}

.ctt-probs {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 1px;
  width: 100%;
}

.ctt-prob {
  font-size: 9px;
  white-space: nowrap;
  display: flex;
  align-items: center;
  gap: 2px;
}

.ctt-prob-dot {
  width: 5px;
  height: 5px;
  border-radius: 50%;
  flex-shrink: 0;
}

/* Next-draw probability \u2014 teal */
.ctt-prob--next .ctt-prob-dot { background: #2a9d8f; }
.ctt-prob--next .ctt-prob-val { color: #2a9d8f; }

/* Rest-of-game probability \u2014 amber */
.ctt-prob--rest .ctt-prob-dot { background: #e07b39; }
.ctt-prob--rest .ctt-prob-val { color: #e07b39; }

.ctt-cell--inhand .ctt-img {
  outline: 2px solid #2a9d8f;
  outline-offset: 1px;
  border-radius: 4px;
}

.ctt-cell--selected {
  background: #e8d5b0;
}

.ctt-cell--selected .ctt-img {
  outline: 2px solid #c8a97e;
  outline-offset: 1px;
  border-radius: 4px;
}

/* Combined probability bar in header */
.ctt-combined {
  font-size: 11px;
  font-weight: 400;
  color: #f5e6d0;
  display: flex;
  align-items: center;
  gap: 5px;
  padding: 3px 0 1px;
  border-top: 1px solid rgba(255,255,255,0.15);
  margin-top: 2px;
}

.ctt-combined-dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: #f5c842;
  flex-shrink: 0;
}

.ctt-combined strong {
  color: #f5c842;
}

.ctt-cell--depleted .ctt-label { color: #bbb; }
.ctt-cell--depleted .ctt-prob-dot,
.ctt-cell--depleted .ctt-prob-val { color: #ccc; background: #ccc; }

/* \u2500\u2500 Utility \u2500\u2500 */
.ctt-hidden {
  display: none !important;
}
`;var b=null,y=null,f=null,h=null,D=!1,p=new Set,S=null;function A(){b?.querySelectorAll(".ctt-cell").forEach(s=>{s.classList.toggle("ctt-cell--selected",p.has(s.dataset.tileId??""))})}function R(){if(!(!h||!S))if(p.size===2){let[s,t]=[...p],n=S(s,t);h.innerHTML=`<span class="ctt-combined-dot"></span>Combined chance to draw both: <strong>${n}%</strong>`,h.classList.remove("ctt-hidden")}else h.classList.add("ctt-hidden")}function _(s){return chrome.runtime.getURL(`tiles/${s}.png`)}function P(s){if(S=s,document.getElementById("ctt-styles"))return;let t=document.createElement("style");t.id="ctt-styles",t.textContent=N,document.head.appendChild(t);let n=document.createElement("div");n.className="ctt-root",n.id="ctt-root",f=document.createElement("div"),f.className="ctt-panel ctt-hidden";let o=document.createElement("div");o.className="ctt-header";let r=document.createElement("div");r.className="ctt-header-top";let i=document.createElement("span");i.className="ctt-header-title",i.textContent="Tiles Remaining",y=document.createElement("span"),y.className="ctt-total",y.textContent="72 / 72",r.appendChild(i),r.appendChild(y),o.appendChild(r);let c=document.createElement("div");c.className="ctt-scores",c.id="ctt-scores",o.appendChild(c);let a=document.createElement("div");a.className="ctt-legend",a.innerHTML='<span class="ctt-legend-item"><span class="ctt-legend-dot ctt-legend-dot--next"></span>next draw</span><span class="ctt-legend-item"><span class="ctt-legend-dot ctt-legend-dot--rest"></span>2p game</span>',o.appendChild(a),h=document.createElement("div"),h.className="ctt-combined ctt-hidden",o.appendChild(h),f.appendChild(o),b=document.createElement("div"),b.className="ctt-grid",f.appendChild(b),n.appendChild(f);let e=document.createElement("button");e.className="ctt-toggle",e.title="Carcassonne Tile Tracker \u2014 click to open/close",e.textContent="\u{1F3F0}",e.addEventListener("click",()=>{D=!D,f.classList.toggle("ctt-hidden",!D)}),n.appendChild(e),document.body.appendChild(n)}function v({tiles:s,opponentDrawsNext:t,players:n}){if(!b||!y)return;let o=s.reduce((e,l)=>e+l.inDeck,0),r=s.reduce((e,l)=>e+l.total,0);y.textContent=`${o} / ${r} in deck`;let i=document.getElementById("ctt-scores");i&&n.length>0&&(i.innerHTML=n.map(e=>{let l=`<span class="ctt-score-dot" style="background:#${e.color.replace(/^#/,"")}"></span>`,u=e.isActive?" ctt-score--active":"",d=e.partialScore>e.score?`<span class="ctt-score-partial">(${e.partialScore})</span>`:"";return`<span class="ctt-score-player${u}">${l}<span class="ctt-score-name">${e.name}</span><span class="ctt-score-val">${e.score}${d}</span></span>`}).join('<span class="ctt-score-sep">vs</span>'));let c=f.querySelector(".ctt-legend-item:first-child");c&&(c.textContent=t?"opp. next draw":"your next draw");let a=document.createElement("span");a.className="ctt-legend-dot ctt-legend-dot--next",c&&c.insertBefore(a,c.firstChild),b.innerHTML="";for(let e of s){let l=e.inDeck===0&&e.inHand===0,u="ctt-cell";l&&(u+=" ctt-cell--depleted"),e.inHand>0&&(u+=" ctt-cell--inhand");let d=document.createElement("div");d.className=u,d.title=`Tile ${e.id}: ${e.inDeck} in deck`+(e.inHand>0?`, ${e.inHand} in hand`:"")+` / ${e.total} total`,d.dataset.tileId=e.id,p.has(e.id)&&(u+=" ctt-cell--selected"),d.addEventListener("click",()=>{p.has(e.id)?p.delete(e.id):(p.size<2||p.delete([...p][0]),p.add(e.id)),A(),R()});let g=document.createElement("img");g.className="ctt-img",g.src=_(e.id),g.alt=`Tile ${e.id}`,d.appendChild(g);let m=document.createElement("div");m.className="ctt-label",m.textContent=`${e.inDeck+e.inHand}/${e.total}`,d.appendChild(m);let k=document.createElement("div");k.className="ctt-probs";let M=(I,z)=>{let C=document.createElement("div");C.className=`ctt-prob ${I}`;let L=document.createElement("span");L.className="ctt-prob-dot";let T=document.createElement("span");return T.className="ctt-prob-val",T.textContent=e.inDeck>0?`${z}%`:"\u2014",C.appendChild(L),C.appendChild(T),C};k.appendChild(M("ctt-prob--next",e.nextPct)),k.appendChild(M("ctt-prob--rest",e.restPct)),d.appendChild(k),b.appendChild(d)}}function B(){let s=new E;P((n,o)=>s.combinedProb(n,o)),v(s.stats());let t=document.createElement("script");t.src=chrome.runtime.getURL("injected.js"),t.onload=()=>t.remove(),(document.head??document.documentElement).appendChild(t),window.addEventListener("message",n=>{if(!(!n.data||typeof n.data!="object")&&n.data.source==="CTT_")if(n.data.type==="UPDATE_STATE"){let o=n.data.placedTypes??[],r=n.data.handTypes??[],i=typeof n.data.deckSize=="number"?n.data.deckSize:0,c=Array.isArray(n.data.players)?n.data.players.map(a=>({...a,partialScore:typeof a.partialScore=="number"?a.partialScore:a.score})):[];s.setState(o,r,i,c),v(s.stats())}else n.data.type==="TILE_PLACED"&&(s.place(String(n.data.bgaType??"")),v(s.stats()))})}B();})();
