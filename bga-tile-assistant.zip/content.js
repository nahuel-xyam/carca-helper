"use strict";(()=>{var b=[{id:"A",count:2},{id:"B",count:4},{id:"C",count:1},{id:"F",count:2},{id:"G",count:1},{id:"H",count:3},{id:"I",count:2},{id:"E",count:5},{id:"D",count:4},{id:"J",count:3},{id:"K",count:3},{id:"L",count:3},{id:"W",count:4},{id:"X",count:1},{id:"U",count:8},{id:"V",count:9},{id:"Q",count:1},{id:"R",count:3},{id:"S",count:2},{id:"T",count:1},{id:"M",count:2},{id:"N",count:3},{id:"O",count:2},{id:"P",count:3}],j=Object.fromEntries(b.map(o=>[o.id,o]));var w={1:"T",2:"S",3:"N",4:"M",5:"P",6:"O",7:"G",8:"F",9:"I",10:"H",11:"E",12:"K",13:"J",14:"L",15:"D",16:"U",17:"V",18:"W",19:"X",20:"B",21:"A",22:"C",23:"R",24:"Q"};function A(o,n,e){if(n<=0||o<=0)return 0;if(n>e)return 1;let i=1;for(let a=0;a<n;a++)i*=(e-a)/(o-a);return Math.max(0,Math.min(1,1-i))}var v=class{constructor(){this.deckCounts=new Map;this.handCounts=new Map;this.totals=new Map;this.bgaDeckSize=0;this._players=[];for(let n of b)this.deckCounts.set(n.id,n.count),this.handCounts.set(n.id,0),this.totals.set(n.id,n.count)}updateScores(n,e){n.length>0&&(this._players=n),e>0&&(this.bgaDeckSize=e)}place(n){let e=w[n];if(!e)return;let i=this.handCounts.get(e)??0;if(i>0)this.handCounts.set(e,i-1);else{let a=this.deckCounts.get(e)??0;a>0&&this.deckCounts.set(e,a-1),this.bgaDeckSize>0&&(this.bgaDeckSize=Math.max(0,this.bgaDeckSize-1))}}setState(n,e,i=0,a=[]){this.bgaDeckSize=i,this._players=a;for(let c of b)this.deckCounts.set(c.id,c.count),this.handCounts.set(c.id,0);for(let c of n){let t=w[c];if(!t)continue;let s=this.deckCounts.get(t)??0;this.deckCounts.set(t,Math.max(0,s-1))}for(let c of e){let t=w[c];if(!t)continue;let s=this.deckCounts.get(t)??0;this.deckCounts.set(t,Math.max(0,s-1)),this.handCounts.set(t,(this.handCounts.get(t)??0)+1)}}get totalInDeck(){if(this.bgaDeckSize>0)return this.bgaDeckSize;let n=0;for(let e of this.deckCounts.values())n+=e;return n}get totalLeft(){let n=0;for(let[e,i]of this.deckCounts)n+=i+(this.handCounts.get(e)??0);return n}stats(){let n=this.totalInDeck,e=[...this.handCounts.values()].some(c=>c>0),i=e?Math.ceil(n/2):Math.floor(n/2);return{tiles:b.map(c=>{let t=this.deckCounts.get(c.id)??0,s=this.handCounts.get(c.id)??0,d=n>0?Math.round(A(n,t,i)*100):0,r=d>0&&n>0?Math.round(t/n*100):0;return{id:c.id,inDeck:t,inHand:s,total:this.totals.get(c.id)??c.count,nextPct:r,restPct:d}}),opponentDrawsNext:e,players:this._players}}combinedProb(n,e){let i=this.totalInDeck;if(i===0)return 0;let c=[...this.handCounts.values()].some(p=>p>0)?Math.ceil(i/2):Math.floor(i/2),t=this.deckCounts.get(n)??0,s=this.deckCounts.get(e)??0,d=n===e?t:t+s,r=p=>{if(p<=0)return 1;if(p>c)return 0;let m=1;for(let h=0;h<p;h++)m*=(c-h)/(i-h);return m},u=1-r(t)-r(s)+r(d);return Math.round(Math.max(0,Math.min(1,u))*100)}reset(){this.bgaDeckSize=0;for(let n of b)this.deckCounts.set(n.id,n.count),this.handCounts.set(n.id,0)}};var M=`/* Carcassonne Tile Tracker \u2014 all classes prefixed ctt- to avoid BGA conflicts */

.ctt-root {
  position: fixed;
  bottom: 16px;
  left: 16px;
  z-index: 2147483647;
  font-family: system-ui, -apple-system, sans-serif;
  font-size: 13px;
  line-height: 1.3;
  color: #1a1a2e;
  user-select: none;
  pointer-events: none; /* children opt back in */
}

/* \u2500\u2500 Toggle button \u2500\u2500 */
.ctt-toggle {
  pointer-events: auto;
  width: 40px;
  height: 40px;
  border-radius: 8px;
  background: #4a3728;
  color: #f5e6d0;
  border: 2px solid #c8a97e;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 20px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.45);
  transition: background 0.15s, transform 0.1s;
  padding: 0;
}

.ctt-toggle:hover {
  background: #6b4f3a;
  transform: scale(1.05);
}

/* \u2500\u2500 Panel card \u2500\u2500 */
.ctt-panel {
  pointer-events: auto;
  position: fixed;
  bottom: 64px;
  left: 16px;
  width: 512px;
  max-width: min(512px, calc(100vw - 32px));
  background: #faf6ef;
  border-radius: 10px;
  box-shadow: 0 6px 28px rgba(0, 0, 0, 0.35);
  border: 1px solid #c8a97e;
  overflow: hidden;
}

.ctt-header {
  background: #4a3728;
  color: #f5e6d0;
  padding: 8px 12px;
  font-weight: 700;
  font-size: 13px;
  display: flex;
  flex-direction: column;
  gap: 4px;
  pointer-events: auto;
}

.ctt-header-top {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

/* \u2500\u2500 Player scores \u2500\u2500 */
.ctt-scores {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 4px 0 2px;
  /* border-bottom: 1px solid rgba(255,255,255,0.12); */
  margin-bottom: 2px;
  flex-wrap: wrap;
}

.ctt-score-player {
  display: flex;
  align-items: center;
  gap: 4px;
  font-size: 12px;
  font-weight: 400;
  opacity: 0.85;
}

.ctt-score-player.ctt-score--active {
  opacity: 1;
  font-weight: 700;
}

.ctt-score-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  flex-shrink: 0;
  border: 1px solid rgba(255,255,255,0.4);
}

.ctt-score-name {
  max-width: 120px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.ctt-score-val {
  font-weight: 700;
  margin-left: 2px;
  color: #f5c842;
}

.ctt-score-partial {
  font-weight: 400;
  font-size: 10px;
  color: #e0c060;
  margin-left: 2px;
  opacity: 0.85;
}

.ctt-score-sep {
  font-size: 10px;
  opacity: 0.5;
  font-style: italic;
}

.ctt-legend { display: none; }

.ctt-header-title {
  white-space: nowrap;
  flex: 1;
}

.ctt-refresh-btn {
  background: none;
  border: none;
  color: #f5e6d0;
  font-size: 18px;
  cursor: pointer;
  padding: 0;
  opacity: 0.55;
  line-height: 1;
  flex-shrink: 0;
  pointer-events: auto;
  transition: opacity 0.15s;
  width: 24px;
}

.ctt-refresh-btn:hover {
  opacity: 1;
}

@keyframes ctt-spin {
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
}

.ctt-refresh-btn--spinning {
  animation: ctt-spin 0.6s linear;
  opacity: 1;
}

.ctt-total {
  font-size: 12px;
  font-weight: 400;
  opacity: 0.85;
  white-space: nowrap;
}

/* \u2500\u2500 Tile grid \u2500\u2500 */
.ctt-grid {
  display: grid;
  grid-template-columns: repeat(8, 1fr);
  gap: 0;
  padding: 8px;
  overflow-x: auto;
  -webkit-overflow-scrolling: touch;
}

@media (max-width: 360px) {
  .ctt-grid {
    grid-template-columns: repeat(8, 40px);
  }
}
/* Small screens: shrink tiles to 40px so 8 columns fit within ~360px */
@media (max-width: 499px) {
  .ctt-grid {
    grid-template-columns: repeat(8, 0.8fr);
  }
}

/* \u2500\u2500 Individual tile cell \u2500\u2500 */
.ctt-cell {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 2px;
  padding: 4px 0 3px;
  border-radius: 6px;
  transition: background 0.1s;
}

.ctt-cell:hover {
  background: #ecdfc8;
}

.ctt-cell--depleted {
  opacity: 0.3;
  filter: grayscale(1);
}

.ctt-img {
  width: 56px;
  height: 56px;
  image-rendering: pixelated;
  border-radius: 3px;
  display: block;
}

@media (max-width: 499px) {
  .ctt-img { width: 40px; height: 40px; }
  .ctt-label { font-size: 9px; }
  .ctt-prob { font-size: 8px; }
}

.ctt-label {
  font-size: 10px;
  font-weight: 700;
  color: #4a3728;
  white-space: nowrap;
  letter-spacing: 0.02em;
}

.ctt-probs {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 1px;
  width: 100%;
}

.ctt-prob {
  font-size: 9px;
  white-space: nowrap;
  display: flex;
  align-items: center;
  gap: 2px;
}

.ctt-prob-dot {
  width: 5px;
  height: 5px;
  border-radius: 50%;
  flex-shrink: 0;
}

/* Next-draw probability \u2014 teal */
.ctt-prob--next .ctt-prob-dot { background: #2a9d8f; }
.ctt-prob--next .ctt-prob-val { color: #2a9d8f; }

/* Rest-of-game probability \u2014 amber */
.ctt-prob--rest .ctt-prob-dot { background: #e07b39; }
.ctt-prob--rest .ctt-prob-val { color: #e07b39; }

.ctt-cell--inhand .ctt-img {
  outline: 2px solid #2a9d8f;
  outline-offset: 1px;
  border-radius: 4px;
}

.ctt-cell--selected {
  background: #e8d5b0;
}

.ctt-cell--selected .ctt-img {
  outline: 2px solid #c8a97e;
  outline-offset: 1px;
  border-radius: 4px;
}

/* Combined probability bar in header */
.ctt-combined {
  font-size: 11px;
  font-weight: 400;
  color: #f5e6d0;
  display: flex;
  align-items: center;
  gap: 5px;
  padding: 3px 0 1px;
  border-top: 1px solid rgba(255,255,255,0.15);
  /* margin-top: 2px; */
}

.ctt-combined-dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: #f5c842;
  flex-shrink: 0;
}

.ctt-combined-dot--hint {
  background: rgba(245, 230, 208, 0.35);
  border: 1px solid rgba(245, 230, 208, 0.4);
}

.ctt-combined-hint {
  opacity: 0.55;
  font-style: italic;
  font-weight: 400;
}

.ctt-combined strong {
  color: #f5c842;
}

.ctt-cell--depleted .ctt-label { color: #bbb; }
.ctt-cell--depleted .ctt-prob-dot,
.ctt-cell--depleted .ctt-prob-val { color: #ccc; background: #ccc; }

/* \u2500\u2500 Utility \u2500\u2500 */
.ctt-hidden {
  display: none !important;
}
`;var g=null,y=null,x=null,f=null,E=!1,l=new Set,S=null,P=null;function z(o){P=o}function L(){P?.()}function R(){g?.querySelectorAll(".ctt-cell").forEach(o=>{o.classList.toggle("ctt-cell--selected",l.has(o.dataset.tileId??""))})}function _(){if(!(!f||!S))if(l.size===2){let[o,n]=[...l],e=S(o,n);f.innerHTML=`<span class="ctt-combined-dot"></span>Combined chance to draw both: <strong>${e}%</strong>`}else f.innerHTML='<span class="ctt-combined-dot ctt-combined-dot--hint"></span><span class="ctt-combined-hint">Tap 2 tiles to see combined draw chance</span>'}function U(o){return chrome.runtime.getURL(`tiles/${o}.png`)}function N(o){if(S=o,document.getElementById("ctt-styles"))return;let n=document.createElement("style");n.id="ctt-styles",n.textContent=M,document.head.appendChild(n);let e=document.createElement("div");e.className="ctt-root",e.id="ctt-root",x=document.createElement("div"),x.className="ctt-panel ctt-hidden";let i=document.createElement("div");i.className="ctt-header";let a=document.createElement("div");a.className="ctt-header-top";let c=document.createElement("span");c.className="ctt-header-title",c.textContent="Tiles Remaining",y=document.createElement("span"),y.className="ctt-total",y.textContent="72 / 72";let t=document.createElement("button");t.className="ctt-refresh-btn",t.title="Click to update remaining tiles",t.textContent="\u21BB",t.addEventListener("click",u=>{u.stopPropagation(),t.classList.add("ctt-refresh-btn--spinning"),L(),setTimeout(()=>t.classList.remove("ctt-refresh-btn--spinning"),800)});let s=document.createElement("span");s.style.cssText="display:flex;align-items:center;gap:4px;",s.appendChild(c),s.appendChild(t),a.appendChild(s),a.appendChild(y),i.appendChild(a);let d=document.createElement("div");d.className="ctt-scores",d.id="ctt-scores",i.appendChild(d),f=document.createElement("div"),f.className="ctt-combined",f.innerHTML='<span class="ctt-combined-dot ctt-combined-dot--hint"></span><span class="ctt-combined-hint">Tap 2 tiles to see combined draw chance</span>',i.appendChild(f),x.appendChild(i),g=document.createElement("div"),g.className="ctt-grid",x.appendChild(g),e.appendChild(x);let r=document.createElement("button");r.className="ctt-toggle",r.title="Carcassonne Tile Tracker \u2014 click to open/close",r.textContent="\u{1F3F0}",r.addEventListener("click",()=>{E=!E,x.classList.toggle("ctt-hidden",!E),E&&L()}),e.appendChild(r),document.body.appendChild(e)}function k({tiles:o,opponentDrawsNext:n,players:e}){if(!g||!y)return;let i=o.reduce((t,s)=>t+s.inDeck,0),a=o.reduce((t,s)=>t+s.total,0);y.textContent=`${i} / ${a} in deck`;let c=document.getElementById("ctt-scores");c&&e.length>0&&(c.innerHTML=e.map(t=>{let s=`<span class="ctt-score-dot" style="background:#${t.color.replace(/^#/,"")}"></span>`;return`<span class="ctt-score-player${t.isActive?" ctt-score--active":""}">${s}<span class="ctt-score-name">${t.name}</span><span class="ctt-score-val">${t.score}</span></span>`}).join('<span class="ctt-score-sep">vs</span>')),g.innerHTML="";for(let t of o){let s=t.inDeck===0&&t.inHand===0,d="ctt-cell";s&&(d+=" ctt-cell--depleted");let r=document.createElement("div");r.className=d,r.title=`Tile ${t.id}: ${t.inDeck+t.inHand} remaining / ${t.total} total`,r.dataset.tileId=t.id,l.has(t.id)&&(d+=" ctt-cell--selected"),r.addEventListener("click",()=>{l.has(t.id)?l.delete(t.id):(l.size<2||l.delete([...l][0]),l.add(t.id)),R(),_()});let u=document.createElement("img");u.className="ctt-img",u.src=U(t.id),u.alt=`Tile ${t.id}`,r.appendChild(u);let p=document.createElement("div");p.className="ctt-label",p.textContent=`${t.inDeck+t.inHand}/${t.total}`,r.appendChild(p);let m=document.createElement("div");m.className="ctt-probs";let h=(I,H)=>{let C=document.createElement("div");C.className=`ctt-prob ${I}`;let D=document.createElement("span");D.className="ctt-prob-dot";let T=document.createElement("span");return T.className="ctt-prob-val",T.textContent=t.inDeck>0?`${H}%`:"\u2014",C.appendChild(D),C.appendChild(T),C};m.appendChild(h("ctt-prob--next",t.nextPct)),m.appendChild(h("ctt-prob--rest",t.restPct)),r.appendChild(m),g.appendChild(r)}}function B(){let o=new v;N((e,i)=>o.combinedProb(e,i)),z(()=>window.postMessage({source:"CTT_",type:"RESCAN"},"*")),k(o.stats());let n=document.createElement("script");n.src=chrome.runtime.getURL("injected.js"),n.onload=()=>n.remove(),(document.head??document.documentElement).appendChild(n),window.addEventListener("message",e=>{if(!(!e.data||typeof e.data!="object")&&e.data.source==="CTT_"){if(e.data.type==="UPDATE_STATE"){let i=e.data.placedTypes??[],a=e.data.handTypes??[],c=typeof e.data.deckSize=="number"?e.data.deckSize:0,t=Array.isArray(e.data.players)?e.data.players.map(s=>({...s,partialScore:typeof s.partialScore=="number"?s.partialScore:s.score})):[];o.setState(i,a,c,t),k(o.stats())}else if(e.data.type==="TILE_PLACED")o.place(String(e.data.bgaType??"")),k(o.stats());else if(e.data.type==="SCORE_UPDATE"){let i=Array.isArray(e.data.players)?e.data.players:[],a=typeof e.data.deckSize=="number"?e.data.deckSize:0;o.updateScores(i,a),k(o.stats())}}})}B();})();
