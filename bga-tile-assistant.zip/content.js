"use strict";(()=>{var l=[{id:"A",count:2},{id:"B",count:4},{id:"C",count:1},{id:"D",count:4},{id:"E",count:5},{id:"F",count:2},{id:"G",count:1},{id:"H",count:3},{id:"I",count:2},{id:"J",count:3},{id:"K",count:3},{id:"L",count:3},{id:"M",count:2},{id:"N",count:3},{id:"O",count:2},{id:"P",count:3},{id:"Q",count:1},{id:"R",count:3},{id:"S",count:2},{id:"T",count:1},{id:"U",count:8},{id:"V",count:9},{id:"W",count:4},{id:"X",count:1}],H=Object.fromEntries(l.map(i=>[i.id,i]));var C={1:"T",2:"S",3:"N",4:"M",5:"P",6:"O",7:"G",8:"F",9:"I",10:"H",11:"E",12:"K",13:"J",14:"L",15:"D",16:"U",17:"V",18:"W",19:"X",20:"B",21:"A",22:"C",23:"R",24:"Q"};function M(i,t,n){if(t<=0||i<=0)return 0;if(t>n)return 1;let a=1;for(let c=0;c<t;c++)a*=(n-c)/(i-c);return Math.max(0,Math.min(1,1-a))}var x=class{constructor(){this.deckCounts=new Map;this.handCounts=new Map;this.totals=new Map;this.bgaDeckSize=0;for(let t of l)this.deckCounts.set(t.id,t.count),this.handCounts.set(t.id,0),this.totals.set(t.id,t.count)}setState(t,n,a=0){this.bgaDeckSize=a;for(let c of l)this.deckCounts.set(c.id,c.count),this.handCounts.set(c.id,0);for(let c of t){let o=C[c];if(!o)continue;let e=this.deckCounts.get(o)??0;this.deckCounts.set(o,Math.max(0,e-1))}for(let c of n){let o=C[c];if(!o)continue;let e=this.deckCounts.get(o)??0;this.deckCounts.set(o,Math.max(0,e-1)),this.handCounts.set(o,(this.handCounts.get(o)??0)+1)}}get totalInDeck(){if(this.bgaDeckSize>0)return this.bgaDeckSize;let t=0;for(let n of this.deckCounts.values())t+=n;return t}get totalLeft(){let t=0;for(let[n,a]of this.deckCounts)t+=a+(this.handCounts.get(n)??0);return t}stats(){let t=this.totalInDeck,n=[...this.handCounts.values()].some(o=>o>0),a=n?Math.ceil(t/2):Math.floor(t/2);return{tiles:l.map(o=>{let e=this.deckCounts.get(o.id)??0,s=this.handCounts.get(o.id)??0,m=t>0?Math.round(e/t*100):0,d=Math.round(M(t,e,a)*100);return{id:o.id,inDeck:e,inHand:s,total:this.totals.get(o.id)??o.count,nextPct:m,restPct:d}}),opponentDrawsNext:n}}reset(){this.bgaDeckSize=0;for(let t of l)this.deckCounts.set(t.id,t.count),this.handCounts.set(t.id,0)}};var v=`/* Carcassonne Tile Tracker \u2014 all classes prefixed ctt- to avoid BGA conflicts */

.ctt-root {
  position: fixed;
  bottom: 16px;
  left: 16px;
  z-index: 2147483647;
  font-family: system-ui, -apple-system, sans-serif;
  font-size: 13px;
  line-height: 1.3;
  color: #1a1a2e;
  user-select: none;
  pointer-events: none; /* children opt back in */
}

/* \u2500\u2500 Toggle button \u2500\u2500 */
.ctt-toggle {
  pointer-events: auto;
  width: 40px;
  height: 40px;
  border-radius: 8px;
  background: #4a3728;
  color: #f5e6d0;
  border: 2px solid #c8a97e;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 20px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.45);
  transition: background 0.15s, transform 0.1s;
  padding: 0;
}

.ctt-toggle:hover {
  background: #6b4f3a;
  transform: scale(1.05);
}

/* \u2500\u2500 Panel card \u2500\u2500 */
.ctt-panel {
  pointer-events: auto;
  position: fixed;
  bottom: 64px;
  left: 16px;
  width: 512px;
  max-width: calc(100% - 32px);
  background: #faf6ef;
  border-radius: 10px;
  box-shadow: 0 6px 28px rgba(0, 0, 0, 0.35);
  border: 1px solid #c8a97e;
  overflow: hidden;
}

.ctt-header {
  background: #4a3728;
  color: #f5e6d0;
  padding: 8px 12px;
  font-weight: 700;
  font-size: 13px;
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.ctt-header-top {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.ctt-legend {
  display: flex;
  gap: 10px;
  font-size: 10px;
  font-weight: 400;
  opacity: 0.85;
}

.ctt-legend-item {
  display: flex;
  align-items: center;
  gap: 3px;
}

.ctt-legend-dot {
  width: 6px;
  height: 6px;
  border-radius: 50%;
}

.ctt-legend-dot--next { background: #2a9d8f; }
.ctt-legend-dot--rest { background: #e07b39; }

.ctt-header-title {
  white-space: nowrap;
}

.ctt-total {
  font-size: 12px;
  font-weight: 400;
  opacity: 0.85;
  white-space: nowrap;
}

/* \u2500\u2500 Tile grid \u2500\u2500 */
.ctt-grid {
  display: grid;
  grid-template-columns: repeat(8, 1fr);
  gap: 4px;
  padding: 8px;
}

/* \u2500\u2500 Individual tile cell \u2500\u2500 */
.ctt-cell {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 2px;
  padding: 4px 2px 3px;
  border-radius: 6px;
  transition: background 0.1s;
}

.ctt-cell:hover {
  background: #ecdfc8;
}

.ctt-cell--depleted {
  opacity: 0.3;
  filter: grayscale(1);
}

.ctt-img {
  width: 56px;
  height: 56px;
  image-rendering: pixelated;
  border-radius: 3px;
  display: block;
}

.ctt-label {
  font-size: 10px;
  font-weight: 700;
  color: #4a3728;
  white-space: nowrap;
  letter-spacing: 0.02em;
}

.ctt-probs {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 1px;
  width: 100%;
}

.ctt-prob {
  font-size: 9px;
  white-space: nowrap;
  display: flex;
  align-items: center;
  gap: 2px;
}

.ctt-prob-dot {
  width: 5px;
  height: 5px;
  border-radius: 50%;
  flex-shrink: 0;
}

/* Next-draw probability \u2014 teal */
.ctt-prob--next .ctt-prob-dot { background: #2a9d8f; }
.ctt-prob--next .ctt-prob-val { color: #2a9d8f; }

/* Rest-of-game probability \u2014 amber */
.ctt-prob--rest .ctt-prob-dot { background: #e07b39; }
.ctt-prob--rest .ctt-prob-val { color: #e07b39; }

.ctt-cell--inhand .ctt-img {
  outline: 2px solid #2a9d8f;
  outline-offset: 1px;
  border-radius: 4px;
}

.ctt-cell--depleted .ctt-label { color: #bbb; }
.ctt-cell--depleted .ctt-prob-dot,
.ctt-cell--depleted .ctt-prob-val { color: #ccc; background: #ccc; }

/* \u2500\u2500 Utility \u2500\u2500 */
.ctt-hidden {
  display: none !important;
}
`;var u=null,p=null,r=null,y=!1;function z(i){return chrome.runtime.getURL(`tiles/${i}.png`)}function D(){if(document.getElementById("ctt-styles"))return;let i=document.createElement("style");i.id="ctt-styles",i.textContent=v,document.head.appendChild(i);let t=document.createElement("div");t.className="ctt-root",t.id="ctt-root",r=document.createElement("div"),r.className="ctt-panel ctt-hidden";let n=document.createElement("div");n.className="ctt-header";let a=document.createElement("div");a.className="ctt-header-top";let c=document.createElement("span");c.className="ctt-header-title",c.textContent="Tiles Remaining",p=document.createElement("span"),p.className="ctt-total",p.textContent="72 / 72",a.appendChild(c),a.appendChild(p),n.appendChild(a);let o=document.createElement("div");o.className="ctt-legend",o.innerHTML='<span class="ctt-legend-item"><span class="ctt-legend-dot ctt-legend-dot--next"></span>next draw</span><span class="ctt-legend-item"><span class="ctt-legend-dot ctt-legend-dot--rest"></span>2p game</span>',n.appendChild(o),r.appendChild(n),u=document.createElement("div"),u.className="ctt-grid",r.appendChild(u),t.appendChild(r);let e=document.createElement("button");e.className="ctt-toggle",e.title="Carcassonne Tile Tracker \u2014 click to open/close",e.textContent="\u{1F3F0}",e.addEventListener("click",()=>{y=!y,r.classList.toggle("ctt-hidden",!y)}),t.appendChild(e),document.body.appendChild(t)}function E({tiles:i,opponentDrawsNext:t}){if(!u||!p)return;let n=i.reduce((e,s)=>e+s.inDeck,0),a=i.reduce((e,s)=>e+s.total,0);p.textContent=`${n} / ${a} in deck`;let c=r.querySelector(".ctt-legend-item:first-child");c&&(c.textContent=t?"opp. next draw":"your next draw");let o=document.createElement("span");o.className="ctt-legend-dot ctt-legend-dot--next",c&&c.insertBefore(o,c.firstChild),u.innerHTML="";for(let e of i){let s=e.inDeck===0&&e.inHand===0,m="ctt-cell";s&&(m+=" ctt-cell--depleted"),e.inHand>0&&(m+=" ctt-cell--inhand");let d=document.createElement("div");d.className=m,d.title=`Tile ${e.id}: ${e.inDeck} in deck`+(e.inHand>0?`, ${e.inHand} in hand`:"")+` / ${e.total} total`;let g=document.createElement("img");g.className="ctt-img",g.src=z(e.id),g.alt=`Tile ${e.id}`,d.appendChild(g);let b=document.createElement("div");b.className="ctt-label",b.textContent=`${e.inDeck+e.inHand}/${e.total}`,d.appendChild(b);let h=document.createElement("div");h.className="ctt-probs";let T=(N,S)=>{let f=document.createElement("div");f.className=`ctt-prob ${N}`;let w=document.createElement("span");w.className="ctt-prob-dot";let k=document.createElement("span");return k.className="ctt-prob-val",k.textContent=e.inDeck>0?`${S}%`:"\u2014",f.appendChild(w),f.appendChild(k),f};h.appendChild(T("ctt-prob--next",e.nextPct)),h.appendChild(T("ctt-prob--rest",e.restPct)),d.appendChild(h),u.appendChild(d)}}function P(){let i=new x;D(),E(i.stats());let t=document.createElement("script");t.src=chrome.runtime.getURL("injected.js"),t.onload=()=>t.remove(),(document.head??document.documentElement).appendChild(t),window.addEventListener("message",n=>{if(!(!n.data||typeof n.data!="object")&&n.data.source==="CTT_"&&n.data.type==="UPDATE_STATE"){let a=n.data.placedTypes??[],c=n.data.handTypes??[],o=typeof n.data.deckSize=="number"?n.data.deckSize:0;i.setState(a,c,o),E(i.stats())}})}P();})();
