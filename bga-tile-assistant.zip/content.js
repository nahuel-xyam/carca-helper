"use strict";(()=>{var x=[{id:"A",count:2},{id:"B",count:4},{id:"C",count:1},{id:"D",count:4},{id:"E",count:5},{id:"F",count:2},{id:"G",count:1},{id:"H",count:3},{id:"I",count:2},{id:"J",count:3},{id:"K",count:3},{id:"L",count:3},{id:"U",count:8},{id:"V",count:9},{id:"W",count:4},{id:"X",count:1},{id:"Q",count:1},{id:"R",count:3},{id:"S",count:2},{id:"T",count:1},{id:"M",count:2},{id:"N",count:3},{id:"O",count:2},{id:"P",count:3}],F=Object.fromEntries(x.map(i=>[i.id,i]));var E={1:"T",2:"S",3:"N",4:"M",5:"P",6:"O",7:"G",8:"F",9:"I",10:"H",11:"E",12:"K",13:"J",14:"L",15:"D",16:"U",17:"V",18:"W",19:"X",20:"B",21:"A",22:"C",23:"R",24:"Q"};function R(i,e,t){if(e<=0||i<=0)return 0;if(e>t)return 1;let c=1;for(let a=0;a<e;a++)c*=(t-a)/(i-a);return Math.max(0,Math.min(1,1-c))}var T=class{constructor(){this.deckCounts=new Map;this.handCounts=new Map;this.totals=new Map;this.bgaDeckSize=0;this._players=[];for(let e of x)this.deckCounts.set(e.id,e.count),this.handCounts.set(e.id,0),this.totals.set(e.id,e.count)}updateScores(e,t){e.length>0&&(this._players=e),t>0&&(this.bgaDeckSize=t)}place(e){let t=E[e];if(!t)return;let c=this.handCounts.get(t)??0;if(c>0)this.handCounts.set(t,c-1);else{let a=this.deckCounts.get(t)??0;a>0&&this.deckCounts.set(t,a-1),this.bgaDeckSize>0&&(this.bgaDeckSize=Math.max(0,this.bgaDeckSize-1))}}setState(e,t,c=0,a=[]){this.bgaDeckSize=c,this._players=a;for(let s of x)this.deckCounts.set(s.id,s.count),this.handCounts.set(s.id,0);for(let s of e){let o=E[s];if(!o)continue;let r=this.deckCounts.get(o)??0;this.deckCounts.set(o,Math.max(0,r-1))}for(let s of t){let o=E[s];if(!o)continue;let r=this.deckCounts.get(o)??0;this.deckCounts.set(o,Math.max(0,r-1)),this.handCounts.set(o,(this.handCounts.get(o)??0)+1)}}get totalInDeck(){if(this.bgaDeckSize>0)return this.bgaDeckSize;let e=0;for(let t of this.deckCounts.values())e+=t;return e}get totalLeft(){let e=0;for(let[t,c]of this.deckCounts)e+=c+(this.handCounts.get(t)??0);return e}stats(){let e=this.totalInDeck,t=[...this.handCounts.values()].some(s=>s>0),c=t?Math.ceil(e/2):Math.floor(e/2);return{tiles:x.map(s=>{let o=this.deckCounts.get(s.id)??0,r=this.handCounts.get(s.id)??0,n=e>0?Math.round(R(e,o,c)*100):0,l=n>0&&e>0?Math.round(o/e*100):0;return{id:s.id,inDeck:o,inHand:r,total:this.totals.get(s.id)??s.count,nextPct:l,restPct:n}}),opponentDrawsNext:t,players:this._players}}combinedProb(e,t){let c=this.totalInDeck;if(c===0)return 0;let s=[...this.handCounts.values()].some(d=>d>0)?Math.ceil(c/2):Math.floor(c/2),o=this.deckCounts.get(e)??0,r=this.deckCounts.get(t)??0,n=e===t?o:o+r,l=d=>{if(d<=0)return 1;if(d>s)return 0;let g=1;for(let m=0;m<d;m++)g*=(s-m)/(c-m);return g},p=1-l(o)-l(r)+l(n);return Math.round(Math.max(0,Math.min(1,p))*100)}reset(){this.bgaDeckSize=0;for(let e of x)this.deckCounts.set(e.id,e.count),this.handCounts.set(e.id,0)}};var N=`/* Carcassonne Tile Tracker \u2014 all classes prefixed ctt- to avoid BGA conflicts */

.ctt-root {
  position: fixed;
  bottom: 16px;
  left: 16px;
  z-index: 2147483647;
  font-family: system-ui, -apple-system, sans-serif;
  font-size: 13px;
  line-height: 1.3;
  color: #1a1a2e;
  user-select: none;
  pointer-events: none; /* children opt back in */
}

/* \u2500\u2500 Toggle button \u2500\u2500 */
.ctt-toggle {
  pointer-events: auto;
  width: 40px;
  height: 40px;
  border-radius: 8px;
  background: #4a3728;
  color: #f5e6d0;
  border: 2px solid #c8a97e;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 20px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.45);
  transition: background 0.15s, transform 0.1s;
  padding: 0;
}

.ctt-toggle:hover {
  background: #6b4f3a;
  transform: scale(1.05);
}

/* \u2500\u2500 Panel card \u2500\u2500 */
.ctt-panel {
  pointer-events: auto;
  position: fixed;
  bottom: 64px;
  left: 16px;
  width: 512px;
  max-width: min(512px, calc(100vw - 32px));
  background: #faf6ef;
  border-radius: 10px;
  box-shadow: 0 6px 28px rgba(0, 0, 0, 0.35);
  border: 1px solid #c8a97e;
  overflow: hidden;
}

.ctt-header {
  background: #4a3728;
  color: #f5e6d0;
  padding: 8px 12px;
  font-weight: 700;
  font-size: 13px;
  display: flex;
  flex-direction: column;
  gap: 4px;
  pointer-events: auto;
}

.ctt-header-top {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

/* \u2500\u2500 Player scores \u2500\u2500 */
.ctt-scores {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 4px 0 2px;
  border-bottom: 1px solid rgba(255,255,255,0.12);
  margin-bottom: 2px;
  flex-wrap: wrap;
}

.ctt-score-player {
  display: flex;
  align-items: center;
  gap: 4px;
  font-size: 12px;
  font-weight: 400;
  opacity: 0.85;
}

.ctt-score-player.ctt-score--active {
  opacity: 1;
  font-weight: 700;
}

.ctt-score-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  flex-shrink: 0;
  border: 1px solid rgba(255,255,255,0.4);
}

.ctt-score-name {
  max-width: 120px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.ctt-score-val {
  font-weight: 700;
  margin-left: 2px;
  color: #f5c842;
}

.ctt-score-partial {
  font-weight: 400;
  font-size: 10px;
  color: #e0c060;
  margin-left: 2px;
  opacity: 0.85;
}

.ctt-score-sep {
  font-size: 10px;
  opacity: 0.5;
  font-style: italic;
}

.ctt-legend {
  display: flex;
  gap: 10px;
  font-size: 10px;
  font-weight: 400;
  opacity: 0.85;
}

.ctt-legend-item {
  display: flex;
  align-items: center;
  gap: 3px;
}

.ctt-legend-dot {
  width: 6px;
  height: 6px;
  border-radius: 50%;
}

.ctt-legend-dot--next { background: #2a9d8f; }
.ctt-legend-dot--rest { background: #e07b39; }

.ctt-header-title {
  white-space: nowrap;
  flex: 1;
}

.ctt-refresh-btn {
  background: none;
  border: none;
  color: #f5e6d0;
  font-size: 18px;
  cursor: pointer;
  padding: 0;
  opacity: 0.55;
  line-height: 1;
  flex-shrink: 0;
  pointer-events: auto;
  transition: opacity 0.15s;
  width: 24px;
}

.ctt-refresh-btn:hover {
  opacity: 1;
}

@keyframes ctt-spin {
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
}

.ctt-refresh-btn--spinning {
  animation: ctt-spin 0.6s linear;
  opacity: 1;
}

.ctt-total {
  font-size: 12px;
  font-weight: 400;
  opacity: 0.85;
  white-space: nowrap;
}

/* \u2500\u2500 Tile grid \u2500\u2500 */
.ctt-grid {
  display: grid;
  grid-template-columns: repeat(8, 1fr);
  gap: 0;
  padding: 8px;
}

/* \u2500\u2500 Individual tile cell \u2500\u2500 */
.ctt-cell {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 2px;
  padding: 4px 0 3px;
  border-radius: 6px;
  transition: background 0.1s;
}

.ctt-cell:hover {
  background: #ecdfc8;
}

.ctt-cell--depleted {
  opacity: 0.3;
  filter: grayscale(1);
}

.ctt-img {
  width: 56px;
  height: 56px;
  image-rendering: pixelated;
  border-radius: 3px;
  display: block;
}

.ctt-label {
  font-size: 10px;
  font-weight: 700;
  color: #4a3728;
  white-space: nowrap;
  letter-spacing: 0.02em;
}

.ctt-probs {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 1px;
  width: 100%;
}

.ctt-prob {
  font-size: 9px;
  white-space: nowrap;
  display: flex;
  align-items: center;
  gap: 2px;
}

.ctt-prob-dot {
  width: 5px;
  height: 5px;
  border-radius: 50%;
  flex-shrink: 0;
}

/* Next-draw probability \u2014 teal */
.ctt-prob--next .ctt-prob-dot { background: #2a9d8f; }
.ctt-prob--next .ctt-prob-val { color: #2a9d8f; }

/* Rest-of-game probability \u2014 amber */
.ctt-prob--rest .ctt-prob-dot { background: #e07b39; }
.ctt-prob--rest .ctt-prob-val { color: #e07b39; }

.ctt-cell--inhand .ctt-img {
  outline: 2px solid #2a9d8f;
  outline-offset: 1px;
  border-radius: 4px;
}

.ctt-cell--selected {
  background: #e8d5b0;
}

.ctt-cell--selected .ctt-img {
  outline: 2px solid #c8a97e;
  outline-offset: 1px;
  border-radius: 4px;
}

/* Combined probability bar in header */
.ctt-combined {
  font-size: 11px;
  font-weight: 400;
  color: #f5e6d0;
  display: flex;
  align-items: center;
  gap: 5px;
  padding: 3px 0 1px;
  border-top: 1px solid rgba(255,255,255,0.15);
  margin-top: 2px;
}

.ctt-combined-dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: #f5c842;
  flex-shrink: 0;
}

.ctt-combined-dot--hint {
  background: rgba(245, 230, 208, 0.35);
  border: 1px solid rgba(245, 230, 208, 0.4);
}

.ctt-combined-hint {
  opacity: 0.55;
  font-style: italic;
  font-weight: 400;
}

.ctt-combined strong {
  color: #f5c842;
}

.ctt-cell--depleted .ctt-label { color: #bbb; }
.ctt-cell--depleted .ctt-prob-dot,
.ctt-cell--depleted .ctt-prob-val { color: #ccc; background: #ccc; }

/* \u2500\u2500 Utility \u2500\u2500 */
.ctt-hidden {
  display: none !important;
}
`;var b=null,y=null,f=null,h=null,v=!1,u=new Set,D=null,z=null;function I(i){z=i}function P(){z?.()}function B(){b?.querySelectorAll(".ctt-cell").forEach(i=>{i.classList.toggle("ctt-cell--selected",u.has(i.dataset.tileId??""))})}function U(){if(!(!h||!D))if(u.size===2){let[i,e]=[...u],t=D(i,e);h.innerHTML=`<span class="ctt-combined-dot"></span>Combined chance to draw both: <strong>${t}%</strong>`}else h.innerHTML='<span class="ctt-combined-dot ctt-combined-dot--hint"></span><span class="ctt-combined-hint">Tap 2 tiles to see combined draw chance</span>'}function j(i){return chrome.runtime.getURL(`tiles/${i}.png`)}function H(i){if(D=i,document.getElementById("ctt-styles"))return;let e=document.createElement("style");e.id="ctt-styles",e.textContent=N,document.head.appendChild(e);let t=document.createElement("div");t.className="ctt-root",t.id="ctt-root",f=document.createElement("div"),f.className="ctt-panel ctt-hidden";let c=document.createElement("div");c.className="ctt-header";let a=document.createElement("div");a.className="ctt-header-top";let s=document.createElement("span");s.className="ctt-header-title",s.textContent="Tiles Remaining",y=document.createElement("span"),y.className="ctt-total",y.textContent="72 / 72";let o=document.createElement("button");o.className="ctt-refresh-btn",o.title="Click to update remaining tiles",o.textContent="\u21BB",o.addEventListener("click",d=>{d.stopPropagation(),o.classList.add("ctt-refresh-btn--spinning"),P(),setTimeout(()=>o.classList.remove("ctt-refresh-btn--spinning"),800)});let r=document.createElement("span");r.style.cssText="display:flex;align-items:center;gap:4px;",r.appendChild(s),r.appendChild(o),a.appendChild(r),a.appendChild(y),c.appendChild(a);let n=document.createElement("div");n.className="ctt-scores",n.id="ctt-scores",c.appendChild(n);let l=document.createElement("div");l.className="ctt-legend",l.innerHTML='<span class="ctt-legend-item"><span class="ctt-legend-dot ctt-legend-dot--next"></span>next draw</span><span class="ctt-legend-item"><span class="ctt-legend-dot ctt-legend-dot--rest"></span>2p game</span>',c.appendChild(l),h=document.createElement("div"),h.className="ctt-combined",h.innerHTML='<span class="ctt-combined-dot ctt-combined-dot--hint"></span><span class="ctt-combined-hint">Tap 2 tiles to see combined draw chance</span>',c.appendChild(h),f.appendChild(c),b=document.createElement("div"),b.className="ctt-grid",f.appendChild(b),t.appendChild(f);let p=document.createElement("button");p.className="ctt-toggle",p.title="Carcassonne Tile Tracker \u2014 click to open/close",p.textContent="\u{1F3F0}",p.addEventListener("click",()=>{v=!v,f.classList.toggle("ctt-hidden",!v),v&&P()}),t.appendChild(p),document.body.appendChild(t)}function k({tiles:i,opponentDrawsNext:e,players:t}){if(!b||!y)return;let c=i.reduce((n,l)=>n+l.inDeck,0),a=i.reduce((n,l)=>n+l.total,0);y.textContent=`${c} / ${a} in deck`;let s=document.getElementById("ctt-scores");s&&t.length>0&&(s.innerHTML=t.map(n=>{let l=`<span class="ctt-score-dot" style="background:#${n.color.replace(/^#/,"")}"></span>`,p=n.isActive?" ctt-score--active":"",d=n.partialScore>n.score?`<span class="ctt-score-partial">(${n.partialScore})</span>`:"";return`<span class="ctt-score-player${p}">${l}<span class="ctt-score-name">${n.name}</span><span class="ctt-score-val">${n.score}${d}</span></span>`}).join('<span class="ctt-score-sep">vs</span>'));let o=f.querySelector(".ctt-legend-item:first-child");o&&(o.textContent=e?"opp. next draw":"your next draw");let r=document.createElement("span");r.className="ctt-legend-dot ctt-legend-dot--next",o&&o.insertBefore(r,o.firstChild),b.innerHTML="";for(let n of i){let l=n.inDeck===0&&n.inHand===0,p="ctt-cell";l&&(p+=" ctt-cell--depleted"),n.inHand>0&&(p+=" ctt-cell--inhand");let d=document.createElement("div");d.className=p,d.title=`Tile ${n.id}: ${n.inDeck} in deck`+(n.inHand>0?`, ${n.inHand} in hand`:"")+` / ${n.total} total`,d.dataset.tileId=n.id,u.has(n.id)&&(p+=" ctt-cell--selected"),d.addEventListener("click",()=>{u.has(n.id)?u.delete(n.id):(u.size<2||u.delete([...u][0]),u.add(n.id)),B(),U()});let g=document.createElement("img");g.className="ctt-img",g.src=j(n.id),g.alt=`Tile ${n.id}`,d.appendChild(g);let m=document.createElement("div");m.className="ctt-label",m.textContent=`${n.inDeck+n.inHand}/${n.total}`,d.appendChild(m);let C=document.createElement("div");C.className="ctt-probs";let M=($,A)=>{let w=document.createElement("div");w.className=`ctt-prob ${$}`;let L=document.createElement("span");L.className="ctt-prob-dot";let S=document.createElement("span");return S.className="ctt-prob-val",S.textContent=n.inDeck>0?`${A}%`:"\u2014",w.appendChild(L),w.appendChild(S),w};C.appendChild(M("ctt-prob--next",n.nextPct)),C.appendChild(M("ctt-prob--rest",n.restPct)),d.appendChild(C),b.appendChild(d)}}function O(){let i=new T;H((t,c)=>i.combinedProb(t,c)),I(()=>window.postMessage({source:"CTT_",type:"RESCAN"},"*")),k(i.stats());let e=document.createElement("script");e.src=chrome.runtime.getURL("injected.js"),e.onload=()=>e.remove(),(document.head??document.documentElement).appendChild(e),window.addEventListener("message",t=>{if(!(!t.data||typeof t.data!="object")&&t.data.source==="CTT_"){if(t.data.type==="UPDATE_STATE"){let c=t.data.placedTypes??[],a=t.data.handTypes??[],s=typeof t.data.deckSize=="number"?t.data.deckSize:0,o=Array.isArray(t.data.players)?t.data.players.map(r=>({...r,partialScore:typeof r.partialScore=="number"?r.partialScore:r.score})):[];i.setState(c,a,s,o),k(i.stats())}else if(t.data.type==="TILE_PLACED")i.place(String(t.data.bgaType??"")),k(i.stats());else if(t.data.type==="SCORE_UPDATE"){let c=Array.isArray(t.data.players)?t.data.players:[],a=typeof t.data.deckSize=="number"?t.data.deckSize:0;i.updateScores(c,a),k(i.stats())}}})}O();})();
