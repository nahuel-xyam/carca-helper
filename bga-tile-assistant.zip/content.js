"use strict";(()=>{var x=[{id:"A",count:2},{id:"B",count:4},{id:"C",count:1},{id:"D",count:4},{id:"E",count:5},{id:"F",count:2},{id:"G",count:1},{id:"H",count:3},{id:"I",count:2},{id:"J",count:3},{id:"K",count:3},{id:"L",count:3},{id:"U",count:8},{id:"V",count:9},{id:"W",count:4},{id:"X",count:1},{id:"Q",count:1},{id:"R",count:3},{id:"S",count:2},{id:"T",count:1},{id:"M",count:2},{id:"N",count:3},{id:"O",count:2},{id:"P",count:3}],U=Object.fromEntries(x.map(s=>[s.id,s]));var E={1:"T",2:"S",3:"N",4:"M",5:"P",6:"O",7:"G",8:"F",9:"I",10:"H",11:"E",12:"K",13:"J",14:"L",15:"D",16:"U",17:"V",18:"W",19:"X",20:"B",21:"A",22:"C",23:"R",24:"Q"};function $(s,e,n){if(e<=0||s<=0)return 0;if(e>n)return 1;let i=1;for(let r=0;r<e;r++)i*=(n-r)/(s-r);return Math.max(0,Math.min(1,1-i))}var w=class{constructor(){this.deckCounts=new Map;this.handCounts=new Map;this.totals=new Map;this.bgaDeckSize=0;this._players=[];for(let e of x)this.deckCounts.set(e.id,e.count),this.handCounts.set(e.id,0),this.totals.set(e.id,e.count)}setState(e,n,i=0,r=[]){this.bgaDeckSize=i,this._players=r;for(let c of x)this.deckCounts.set(c.id,c.count),this.handCounts.set(c.id,0);for(let c of e){let o=E[c];if(!o)continue;let a=this.deckCounts.get(o)??0;this.deckCounts.set(o,Math.max(0,a-1))}for(let c of n){let o=E[c];if(!o)continue;let a=this.deckCounts.get(o)??0;this.deckCounts.set(o,Math.max(0,a-1)),this.handCounts.set(o,(this.handCounts.get(o)??0)+1)}}get totalInDeck(){if(this.bgaDeckSize>0)return this.bgaDeckSize;let e=0;for(let n of this.deckCounts.values())e+=n;return e}get totalLeft(){let e=0;for(let[n,i]of this.deckCounts)e+=i+(this.handCounts.get(n)??0);return e}stats(){let e=this.totalInDeck,n=[...this.handCounts.values()].some(c=>c>0),i=n?Math.ceil(e/2):Math.floor(e/2);return{tiles:x.map(c=>{let o=this.deckCounts.get(c.id)??0,a=this.handCounts.get(c.id)??0,t=e>0?Math.round(o/e*100):0,l=Math.round($(e,o,i)*100);return{id:c.id,inDeck:o,inHand:a,total:this.totals.get(c.id)??c.count,nextPct:t,restPct:l}}),opponentDrawsNext:n,players:this._players}}combinedProb(e,n){let i=this.totalInDeck;if(i===0)return 0;let c=[...this.handCounts.values()].some(d=>d>0)?Math.ceil(i/2):Math.floor(i/2),o=this.deckCounts.get(e)??0,a=this.deckCounts.get(n)??0,t=e===n?o:o+a,l=d=>{if(d<=0)return 1;if(d>c)return 0;let g=1;for(let m=0;m<d;m++)g*=(c-m)/(i-m);return g},u=1-l(o)-l(a)+l(t);return Math.round(Math.max(0,Math.min(1,u))*100)}reset(){this.bgaDeckSize=0;for(let e of x)this.deckCounts.set(e.id,e.count),this.handCounts.set(e.id,0)}};var L=`/* Carcassonne Tile Tracker \u2014 all classes prefixed ctt- to avoid BGA conflicts */

.ctt-root {
  position: fixed;
  bottom: 16px;
  left: 16px;
  z-index: 2147483647;
  font-family: system-ui, -apple-system, sans-serif;
  font-size: 13px;
  line-height: 1.3;
  color: #1a1a2e;
  user-select: none;
  pointer-events: none; /* children opt back in */
}

/* \u2500\u2500 Toggle button \u2500\u2500 */
.ctt-toggle {
  pointer-events: auto;
  width: 40px;
  height: 40px;
  border-radius: 8px;
  background: #4a3728;
  color: #f5e6d0;
  border: 2px solid #c8a97e;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 20px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.45);
  transition: background 0.15s, transform 0.1s;
  padding: 0;
}

.ctt-toggle:hover {
  background: #6b4f3a;
  transform: scale(1.05);
}

/* \u2500\u2500 Panel card \u2500\u2500 */
.ctt-panel {
  pointer-events: auto;
  position: fixed;
  bottom: 64px;
  left: 16px;
  width: 512px;
  max-width: min(512px, calc(100vw - 32px));
  background: #faf6ef;
  border-radius: 10px;
  box-shadow: 0 6px 28px rgba(0, 0, 0, 0.35);
  border: 1px solid #c8a97e;
  overflow: hidden;
}

.ctt-header {
  background: #4a3728;
  color: #f5e6d0;
  padding: 8px 12px;
  font-weight: 700;
  font-size: 13px;
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.ctt-header-top {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

/* \u2500\u2500 Player scores \u2500\u2500 */
.ctt-scores {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 4px 0 2px;
  border-bottom: 1px solid rgba(255,255,255,0.12);
  margin-bottom: 2px;
  flex-wrap: wrap;
}

.ctt-score-player {
  display: flex;
  align-items: center;
  gap: 4px;
  font-size: 12px;
  font-weight: 400;
  opacity: 0.85;
}

.ctt-score-player.ctt-score--active {
  opacity: 1;
  font-weight: 700;
}

.ctt-score-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  flex-shrink: 0;
  border: 1px solid rgba(255,255,255,0.4);
}

.ctt-score-name {
  max-width: 120px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.ctt-score-val {
  font-weight: 700;
  margin-left: 2px;
  color: #f5c842;
}

.ctt-score-partial {
  font-weight: 400;
  font-size: 10px;
  color: #e0c060;
  margin-left: 2px;
  opacity: 0.85;
}

.ctt-score-sep {
  font-size: 10px;
  opacity: 0.5;
  font-style: italic;
}

.ctt-legend {
  display: flex;
  gap: 10px;
  font-size: 10px;
  font-weight: 400;
  opacity: 0.85;
}

.ctt-legend-item {
  display: flex;
  align-items: center;
  gap: 3px;
}

.ctt-legend-dot {
  width: 6px;
  height: 6px;
  border-radius: 50%;
}

.ctt-legend-dot--next { background: #2a9d8f; }
.ctt-legend-dot--rest { background: #e07b39; }

.ctt-header-title {
  white-space: nowrap;
}

.ctt-total {
  font-size: 12px;
  font-weight: 400;
  opacity: 0.85;
  white-space: nowrap;
}

/* \u2500\u2500 Tile grid \u2500\u2500 */
.ctt-grid {
  display: grid;
  grid-template-columns: repeat(8, 1fr);
  gap: 0;
  padding: 8px;
}

/* \u2500\u2500 Individual tile cell \u2500\u2500 */
.ctt-cell {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 2px;
  padding: 4px 0 3px;
  border-radius: 6px;
  transition: background 0.1s;
}

.ctt-cell:hover {
  background: #ecdfc8;
}

.ctt-cell--depleted {
  opacity: 0.3;
  filter: grayscale(1);
}

.ctt-img {
  width: 56px;
  height: 56px;
  image-rendering: pixelated;
  border-radius: 3px;
  display: block;
}

.ctt-label {
  font-size: 10px;
  font-weight: 700;
  color: #4a3728;
  white-space: nowrap;
  letter-spacing: 0.02em;
}

.ctt-probs {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 1px;
  width: 100%;
}

.ctt-prob {
  font-size: 9px;
  white-space: nowrap;
  display: flex;
  align-items: center;
  gap: 2px;
}

.ctt-prob-dot {
  width: 5px;
  height: 5px;
  border-radius: 50%;
  flex-shrink: 0;
}

/* Next-draw probability \u2014 teal */
.ctt-prob--next .ctt-prob-dot { background: #2a9d8f; }
.ctt-prob--next .ctt-prob-val { color: #2a9d8f; }

/* Rest-of-game probability \u2014 amber */
.ctt-prob--rest .ctt-prob-dot { background: #e07b39; }
.ctt-prob--rest .ctt-prob-val { color: #e07b39; }

.ctt-cell--inhand .ctt-img {
  outline: 2px solid #2a9d8f;
  outline-offset: 1px;
  border-radius: 4px;
}

.ctt-cell--selected {
  background: #e8d5b0;
}

.ctt-cell--selected .ctt-img {
  outline: 2px solid #c8a97e;
  outline-offset: 1px;
  border-radius: 4px;
}

/* Combined probability bar in header */
.ctt-combined {
  font-size: 11px;
  font-weight: 400;
  color: #f5e6d0;
  display: flex;
  align-items: center;
  gap: 5px;
  padding: 3px 0 1px;
  border-top: 1px solid rgba(255,255,255,0.15);
  margin-top: 2px;
}

.ctt-combined-dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: #f5c842;
  flex-shrink: 0;
}

.ctt-combined strong {
  color: #f5c842;
}

.ctt-cell--depleted .ctt-label { color: #bbb; }
.ctt-cell--depleted .ctt-prob-dot,
.ctt-cell--depleted .ctt-prob-val { color: #ccc; background: #ccc; }

/* \u2500\u2500 Utility \u2500\u2500 */
.ctt-hidden {
  display: none !important;
}
`;var b=null,y=null,f=null,h=null,T=!1,p=new Set,D=null;function A(){b?.querySelectorAll(".ctt-cell").forEach(s=>{s.classList.toggle("ctt-cell--selected",p.has(s.dataset.tileId??""))})}function R(){if(!(!h||!D))if(p.size===2){let[s,e]=[...p],n=D(s,e);h.innerHTML=`<span class="ctt-combined-dot"></span>Combined chance to draw both: <strong>${n}%</strong>`,h.classList.remove("ctt-hidden")}else h.classList.add("ctt-hidden")}function _(s){return chrome.runtime.getURL(`tiles/${s}.png`)}function P(s){if(D=s,document.getElementById("ctt-styles"))return;let e=document.createElement("style");e.id="ctt-styles",e.textContent=L,document.head.appendChild(e);let n=document.createElement("div");n.className="ctt-root",n.id="ctt-root",f=document.createElement("div"),f.className="ctt-panel ctt-hidden";let i=document.createElement("div");i.className="ctt-header";let r=document.createElement("div");r.className="ctt-header-top";let c=document.createElement("span");c.className="ctt-header-title",c.textContent="Tiles Remaining",y=document.createElement("span"),y.className="ctt-total",y.textContent="72 / 72",r.appendChild(c),r.appendChild(y),i.appendChild(r);let o=document.createElement("div");o.className="ctt-scores",o.id="ctt-scores",i.appendChild(o);let a=document.createElement("div");a.className="ctt-legend",a.innerHTML='<span class="ctt-legend-item"><span class="ctt-legend-dot ctt-legend-dot--next"></span>next draw</span><span class="ctt-legend-item"><span class="ctt-legend-dot ctt-legend-dot--rest"></span>2p game</span>',i.appendChild(a),h=document.createElement("div"),h.className="ctt-combined ctt-hidden",i.appendChild(h),f.appendChild(i),b=document.createElement("div"),b.className="ctt-grid",f.appendChild(b),n.appendChild(f);let t=document.createElement("button");t.className="ctt-toggle",t.title="Carcassonne Tile Tracker \u2014 click to open/close",t.textContent="\u{1F3F0}",t.addEventListener("click",()=>{T=!T,f.classList.toggle("ctt-hidden",!T)}),n.appendChild(t),document.body.appendChild(n)}function S({tiles:s,opponentDrawsNext:e,players:n}){if(!b||!y)return;let i=s.reduce((t,l)=>t+l.inDeck,0),r=s.reduce((t,l)=>t+l.total,0);y.textContent=`${i} / ${r} in deck`;let c=document.getElementById("ctt-scores");c&&n.length>0&&(c.innerHTML=n.map(t=>{let l=`<span class="ctt-score-dot" style="background:#${t.color.replace(/^#/,"")}"></span>`,u=t.isActive?" ctt-score--active":"",d=t.partialScore>t.score?`<span class="ctt-score-partial">(${t.partialScore})</span>`:"";return`<span class="ctt-score-player${u}">${l}<span class="ctt-score-name">${t.name}</span><span class="ctt-score-val">${t.score}${d}</span></span>`}).join('<span class="ctt-score-sep">vs</span>'));let o=f.querySelector(".ctt-legend-item:first-child");o&&(o.textContent=e?"opp. next draw":"your next draw");let a=document.createElement("span");a.className="ctt-legend-dot ctt-legend-dot--next",o&&o.insertBefore(a,o.firstChild),b.innerHTML="";for(let t of s){let l=t.inDeck===0&&t.inHand===0,u="ctt-cell";l&&(u+=" ctt-cell--depleted"),t.inHand>0&&(u+=" ctt-cell--inhand");let d=document.createElement("div");d.className=u,d.title=`Tile ${t.id}: ${t.inDeck} in deck`+(t.inHand>0?`, ${t.inHand} in hand`:"")+` / ${t.total} total`,d.dataset.tileId=t.id,p.has(t.id)&&(u+=" ctt-cell--selected"),d.addEventListener("click",()=>{p.has(t.id)?p.delete(t.id):(p.size<2||p.delete([...p][0]),p.add(t.id)),A(),R()});let g=document.createElement("img");g.className="ctt-img",g.src=_(t.id),g.alt=`Tile ${t.id}`,d.appendChild(g);let m=document.createElement("div");m.className="ctt-label",m.textContent=`${t.inDeck+t.inHand}/${t.total}`,d.appendChild(m);let k=document.createElement("div");k.className="ctt-probs";let M=(I,z)=>{let C=document.createElement("div");C.className=`ctt-prob ${I}`;let N=document.createElement("span");N.className="ctt-prob-dot";let v=document.createElement("span");return v.className="ctt-prob-val",v.textContent=t.inDeck>0?`${z}%`:"\u2014",C.appendChild(N),C.appendChild(v),C};k.appendChild(M("ctt-prob--next",t.nextPct)),k.appendChild(M("ctt-prob--rest",t.restPct)),d.appendChild(k),b.appendChild(d)}}function B(){let s=new w;P((n,i)=>s.combinedProb(n,i)),S(s.stats());let e=document.createElement("script");e.src=chrome.runtime.getURL("injected.js"),e.onload=()=>e.remove(),(document.head??document.documentElement).appendChild(e),window.addEventListener("message",n=>{if(!(!n.data||typeof n.data!="object")&&n.data.source==="CTT_"&&n.data.type==="UPDATE_STATE"){let i=n.data.placedTypes??[],r=n.data.handTypes??[],c=typeof n.data.deckSize=="number"?n.data.deckSize:0,o=Array.isArray(n.data.players)?n.data.players.map(a=>({...a,partialScore:typeof a.partialScore=="number"?a.partialScore:a.score})):[];s.setState(i,r,c,o),S(s.stats())}})}B();})();
